# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.
# --------------------------------------------------------------------------
from olive.systems.python_environment.python_environment_system import PythonEnvironmentSystem

__all__ = ["PythonEnvironmentSystem"]
