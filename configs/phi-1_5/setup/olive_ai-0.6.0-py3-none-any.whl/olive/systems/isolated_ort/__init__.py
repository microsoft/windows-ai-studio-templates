# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.
# --------------------------------------------------------------------------
from olive.systems.isolated_ort.isolated_ort_system import IsolatedORTSystem

__all__ = ["IsolatedORTSystem"]
