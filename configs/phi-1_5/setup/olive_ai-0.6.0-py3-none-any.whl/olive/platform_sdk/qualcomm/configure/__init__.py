# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.
# --------------------------------------------------------------------------

# TODO(anyone): change this sub-module back to a file when `olive.platform_sdk.qualcomm.configure` command
# is removed from Olive.
