# Olive sample code instructions

## Prerequisites
Install Microsoft Visual Studio 2022 for Windows

## Running the same code
Load the included Visual Studio solution, build, and run.
